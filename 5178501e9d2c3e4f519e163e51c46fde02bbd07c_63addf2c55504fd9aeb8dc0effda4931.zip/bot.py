import telegram
import os
import logging
import sqlite3
import random
import string
import threading
import asyncio
import mercadopago
import base64
from datetime import datetime, timedelta
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.date import DateTrigger
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    InputMediaVideo,
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, MessageHandler, ConversationHandler,
    filters, ContextTypes, InlineQueryHandler
)
from flask import Flask, render_template, request, redirect, url_for, session
from telegram.error import BadRequest
from telegram.ext import CallbackContext, InlineQueryHandler
from telegram import InlineQueryResultArticle, InputTextMessageContent
from datetime import datetime, timedelta
from telegram import ForceReply
import uuid
from uuid import uuid4

TOKEN = '7366392963:AAHSUNUJztIiwtdySlisXvMVShns4YrGRzc'
CHANNEL_ID = -1002306488569  # ID do canal onde os anúncios serão publicados
CHANNEL_ID_1 = -1002475705000
ACCESS_TOKEN = "APP_USR-5163700159050061-112312-811f3693e4242c696eeb6c4cf127a32c-1787184825"
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)
AGUARDANDO_VALOR = 1
sdk = mercadopago.SDK(ACCESS_TOKEN)
app = Flask(__name__)
scheduler = AsyncIOScheduler()

DATABASE_PATH = 'meubancodedados.db'
# Dicionário para armazenar o estado dos anúncios dos usuários
user_ads = {}
pagamentos_cancelados = set()
pagamentos_cancelados_lock = asyncio.Lock()
pagamentos_em_progresso = {}

# Adaptação de data e hora recomendada para SQLite
def adapt_datetime(ts):
    return ts.isoformat()

def convert_datetime(ts):
    return datetime.fromisoformat(ts)

sqlite3.register_adapter(datetime, adapt_datetime)
sqlite3.register_converter("timestamp", convert_datetime)

def create_tables():
    """Cria as tabelas necessárias no banco de dados, se não existirem."""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    try:
        # Tabela de usuários
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                telegram_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                start_date TEXT,
                credits INTEGER DEFAULT 0,
                is_blocked INTEGER DEFAULT 0
            )
        ''')

        # Tabela de configuração
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS config (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chave TEXT UNIQUE NOT NULL,
                valor REAL NOT NULL
            )
        """)

        # Configurações padrão
        configuracoes_padrao = [
            ("creditos_minimos", 100),  # Créditos mínimos para criar anúncio
            ("conversao_real_para_credito", 100),  # 1 real = 100 créditos
            ("valor_minimo_credito", 1.00)  # Valor mínimo permitido (em reais)
        ]
        for chave, valor in configuracoes_padrao:
            cursor.execute("INSERT OR IGNORE INTO config (chave, valor) VALUES (?, ?)", (chave, valor))

        # Tabela de planos de contribuição
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS planos_contribuicao (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                valor REAL NOT NULL,
                creditos INTEGER NOT NULL
            )
        """)

        # Tabela de agendamentos
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS agendamentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                media_type TEXT NOT NULL,
                file_id TEXT NOT NULL,
                caption TEXT NOT NULL,
                data_publicacao DATETIME NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(telegram_id)
            )
        ''')

        conn.commit()
        logger.info("Tabelas criadas ou já existentes.")
    except sqlite3.Error as e:
        logger.error(f"Erro ao criar tabelas no banco de dados: {e}")
    finally:
        conn.close()
      
# Chame a função para garantir que as tabelas sejam criadas
create_tables()

def save_user_to_db(telegram_id, username, first_name, last_name):
    """
    Salva o usuário no banco de dados.
    :param telegram_id: ID do usuário no Telegram.
    :param username: Nome de usuário no Telegram.
    :param first_name: Primeiro nome do usuário.
    :param last_name: Último nome do usuário.
    """
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    try:
        # Salva ou ignora o usuário se ele já existir
        cursor.execute('''
            INSERT OR IGNORE INTO users (telegram_id, username, first_name, last_name, start_date)
            VALUES (?, ?, ?, ?, ?)
        ''', (telegram_id, username, first_name, last_name, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        
        conn.commit()
    except sqlite3.Error as e:
        print(f"Erro ao salvar o usuário: {e}")
    finally:
        conn.close()

# Função de verificação de membros no canal
async def is_user_in_channel(bot, user_id: int) -> bool:
    """
    Verifica se o usuário está em ambos os canais obrigatórios.
    :param bot: Instância do bot.
    :param user_id: ID do usuário.
    :return: True se o usuário estiver nos dois canais, False caso contrário.
    """
    try:
        # Verifica se o usuário está no primeiro canal
        chat_member_1 = await bot.get_chat_member(CHANNEL_ID_1, user_id)
        # Verifica se o usuário está no segundo canal
        chat_member_2 = await bot.get_chat_member(CHANNEL_ID, user_id)
        
        # Confirma que o usuário é um membro ativo em ambos os canais
        return chat_member_1.status in ["member", "administrator", "creator"] and \
               chat_member_2.status in ["member", "administrator", "creator"]
    except BadRequest:
        # Caso o usuário não esteja em um dos canais ou o ID esteja errado
        return False

# Função para verificar se o usuário é administrador diretamente pelo ID (ajustar com seus IDs de admin)
def is_admin(user_id):
    admin_ids = [123456789, 987654321]  # IDs dos administradores
    return user_id in admin_ids

# Inicialização da aplicação Flask
def run_flask():
    app.run(host='0.0.0.0', port=80)

@app.route('/vlrparaanuncio', methods=['GET', 'POST'])
def painel():
    # Substitua pelo método correto de obter o ID do administrador
    user_id = 123456789  # Exemplo de ID de administrador
    
    if not is_admin(user_id):  # Verifica se o usuário é admin
        return "Acesso restrito! Somente administradores podem acessar.", 403

    with sqlite3.connect("meubancodedados.db") as conn:
        cursor = conn.cursor()
        
        if request.method == 'POST':
            # Atualizar o valor necessário para criar anúncios
            novo_valor = request.form.get('creditos_minimos')
            if novo_valor:
                cursor.execute(
                    "UPDATE config SET valor = ? WHERE chave = 'creditos_minimos'", 
                    (float(novo_valor),)
                )
                conn.commit()
                return redirect(url_for('painel'))  # Recarrega a página após a atualização

        # Recupera o valor atual dos créditos mínimos
        cursor.execute("SELECT valor FROM config WHERE chave = 'creditos_minimos'")
        creditos_minimos = cursor.fetchone()
        if creditos_minimos:
            creditos_minimos = creditos_minimos[0]
        else:
            creditos_minimos = 0.0  # Define um valor padrão, caso a configuração não exista

    return render_template('painel.html', creditos_minimos=creditos_minimos)


# Página para adicionar valores e créditos
@app.route('/adicionarvalor', methods=['GET', 'POST'])
def adicionar_valor():
    if request.method == 'POST':
        valor = request.form.get('valor', type=float)
        creditos = request.form.get('creditos', type=int)

        if valor > 0 and creditos > 0:
            with sqlite3.connect("meubancodedados.db") as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS planos_contribuicao (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        valor REAL NOT NULL,
                        creditos INTEGER NOT NULL
                    )
                """)
                cursor.execute("INSERT INTO planos_contribuicao (valor, creditos) VALUES (?, ?)", (valor, creditos))
                conn.commit()
        return redirect('/adicionarvalor')

    with sqlite3.connect("meubancodedados.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, valor, creditos FROM planos_contribuicao")
        planos = cursor.fetchall()

    return render_template('adicionarvalor.html', planos=planos)

async def start(update: Update, context: CallbackContext):
    user = update.effective_user  # Obtém o objeto do usuário a partir da atualização
    if user is None:  # Verifica se o objeto user é válido
        await update.message.reply_text("Não foi possível recuperar seus dados. Tente novamente mais tarde.")
        return

    # Extrai informações do usuário
    telegram_id = user.id
    username = user.username
    first_name = user.first_name
    last_name = user.last_name

    # Verifica se o usuário está bloqueado no banco de dados
    conn = sqlite3.connect("meubancodedados.db")  # Substitua pelo caminho correto para o seu banco de dados
    cursor = conn.cursor()

    cursor.execute("SELECT is_blocked FROM users WHERE telegram_id = ?", (telegram_id,))
    result = cursor.fetchone()

    if result and result[0] == 1:  # Verifica se o usuário está bloqueado
        await update.message.reply_text("❌ Você está bloqueado e não pode usar este bot.")
        conn.close()
        return

    # Salva o usuário no banco de dados se ainda não existir
    cursor.execute(
        '''
        INSERT OR IGNORE INTO users (telegram_id, username, first_name, last_name, start_date)
        VALUES (?, ?, ?, ?, DATETIME('now'))
        ''',
        (telegram_id, username, first_name, last_name)
    )
    conn.commit()

    # Verifica se o usuário está nos dois canais
    if not await is_user_in_channel(context.bot, telegram_id):
        await update.message.reply_text(
            "⚠️ Para usar este bot, você precisa entrar nos nossos canais:\n"
            f"1️⃣ [Canal 1](https://t.me/canal1_link)\n"
            f"2️⃣ [Canal 2](https://t.me/canal2_link)\n\n"
            "Depois de entrar, envie /start novamente.",
            parse_mode="Markdown"
        )
        conn.close()
        return

    # Mensagem de boas-vindas
    welcome_message = f"Olá {first_name}, seja bem-vindo. Interaja com os menus abaixo."
    keyboard = [
        [InlineKeyboardButton("📝 Criar Anúncio", callback_data="crate_ad"), InlineKeyboardButton('CONTRIBUIÇÃO', callback_data="contribuir")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    conn.close()

async def contribuir(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    chat_id = query.message.chat_id

    # Recupera os planos de contribuição do banco de dados
    with sqlite3.connect("meubancodedados.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, valor, creditos FROM planos_contribuicao")
        planos = cursor.fetchall()

    if not planos:
        await query.edit_message_text(
            text="Nenhum plano de contribuição disponível no momento.",
            parse_mode="Markdown"
        )
        return

    # Monta os botões para cada plano
    keyboard = []
    for plano in planos:
        plano_id, valor, creditos = plano
        button_text = f"💸 R$ {valor} - {creditos} créditos"
        callback_data = f"contribuir:{plano_id}"
        keyboard.append([InlineKeyboardButton(button_text, callback_data=callback_data)])

    reply_markup = InlineKeyboardMarkup(keyboard)

    await query.edit_message_text(
        text="Escolha um dos planos de contribuição abaixo:",
        reply_markup=reply_markup
    )

async def inline_credits_query(update: Update, context: CallbackContext):
    """
    Trata a pesquisa inline para adicionar créditos a um usuário.
    """
    query = update.inline_query.query.strip()

    try:
        _, _, user_id_str, credits_str = query.split()
        telegram_id = int(user_id_str)
        credits_to_add = int(credits_str)
    except ValueError:
        return  # Formato inválido, não retorna resultados

    # Busca informações do usuário no banco de dados
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT username, first_name, last_name FROM users WHERE telegram_id = ?", (telegram_id,))
        user_data = cursor.fetchone()

        if user_data:
            username, first_name, last_name = user_data
            user_display_name = f"{first_name} {last_name}".strip() or username or f"ID {telegram_id}"

            # Cria os botões de confirmação
            keyboard = [
                [
                    InlineKeyboardButton("Sim", callback_data=f"confirm_yes:{telegram_id}:{credits_to_add}"),
                    InlineKeyboardButton("Não", callback_data=f"confirm_no:{telegram_id}:{credits_to_add}")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)

            # Cria o resultado para a pesquisa inline
            result = InlineQueryResultArticle(
                id=str(uuid.uuid4()),
                title="Confirmar créditos",
                description=f"Adicionar {credits_to_add} créditos ao ID {telegram_id}",
                input_message_content=InputTextMessageContent(
                    message_text=f"Deseja adicionar {credits_to_add} créditos ao ID {telegram_id} ({user_display_name})?",
                    parse_mode="Markdown"
                ),
                reply_markup=reply_markup
            )
            await update.inline_query.answer([result], cache_time=0)
        else:
            # Nenhum usuário encontrado
            result = InlineQueryResultArticle(
                id=str(uuid.uuid4()),
                title="Usuário não encontrado",
                description=f"ID {telegram_id} não encontrado no banco de dados.",
                input_message_content=InputTextMessageContent(
                    message_text=f"Nenhum usuário encontrado com o ID {telegram_id}.",
                    parse_mode="Markdown",
                ),
            )
            await update.inline_query.answer([result], cache_time=0)
    except sqlite3.Error as e:
        logger.error(f"Erro ao buscar usuário: {e}")
    finally:
        conn.close()

async def inline_remove_credits_query(update: Update, context: CallbackContext):
    """
    Trata a pesquisa inline para remover créditos de um usuário.
    """
    query = update.inline_query.query.strip()
    logger.info(f"Recebida pesquisa inline: {query}")  # Log da consulta inicial

    try:
        # Analisa a consulta para garantir que está no formato esperado
        parts = query.split()
        if len(parts) != 5 or parts[0] != "id" or parts[1] != "r" or parts[2] != "credits":
            raise ValueError("Formato inválido")
        
        # Extrai o ID do usuário e a quantidade de créditos
        user_id_str = parts[3]
        credits_str = parts[4]

        telegram_id = int(user_id_str)
        credits_to_remove = int(credits_str)
        logger.info(f"ID do usuário: {telegram_id}, Créditos solicitados para remoção: {credits_to_remove}")
    except ValueError:
        logger.warning("Formato inválido na consulta inline. Esperado: 'id r credits user_id credits'")
        return  # Formato inválido, ignora

    # Conecta ao banco de dados
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Resto do código permanece inalterado
    try:
        logger.info(f"Consultando banco de dados para o ID: {telegram_id}")
        cursor.execute("SELECT username, first_name, last_name, credits FROM users WHERE telegram_id = ?", (telegram_id,))
        user_data = cursor.fetchone()

        if user_data:
            username, first_name, last_name, current_credits = user_data
            user_display_name = f"{first_name} {last_name}".strip() or username or f"ID {telegram_id}"

            logger.info(f"Usuário encontrado: {user_display_name}, Créditos atuais: {current_credits}")

            # Calcula a quantidade de créditos que podem ser removidos
            credits_to_remove = min(credits_to_remove, current_credits)

            # Verifica se há créditos suficientes para remover
            if credits_to_remove <= 0:
                logger.info(f"O usuário {user_display_name} não possui créditos para remover.")
                result = InlineQueryResultArticle(
                    id=str(uuid.uuid4()),
                    title="Créditos insuficientes",
                    description=f"O ID {telegram_id} não tem créditos suficientes para remoção.",
                    input_message_content=InputTextMessageContent(
                        message_text=f"O usuário ({user_display_name}) não possui créditos para remover.",
                        parse_mode="Markdown"
                    )
                )
                await update.inline_query.answer([result], cache_time=0)
                return

            # Cria os botões de confirmação
            keyboard = [
                [
                    InlineKeyboardButton("Sim", callback_data=f"confirm_remove_yes:{telegram_id}:{credits_to_remove}"),
                    InlineKeyboardButton("Não", callback_data=f"confirm_remove_no:{telegram_id}:{credits_to_remove}")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)

            # Cria o resultado para a pesquisa inline
            logger.info(f"Preparando resposta inline para remover {credits_to_remove} créditos.")
            result = InlineQueryResultArticle(
                id=str(uuid.uuid4()),
                title="Confirmar remoção de créditos",
                description=f"Remover {credits_to_remove} créditos do ID {telegram_id}",
                input_message_content=InputTextMessageContent(
                    message_text=f"Deseja remover {credits_to_remove} créditos do ID {telegram_id} ({user_display_name})?",
                    parse_mode="Markdown"
                ),
                reply_markup=reply_markup
            )
            await update.inline_query.answer([result], cache_time=0)
        else:
            logger.warning(f"Usuário não encontrado no banco de dados para o ID {telegram_id}.")
            # Nenhum usuário encontrado
            result = InlineQueryResultArticle(
                id=str(uuid.uuid4()),
                title="Usuário não encontrado",
                description=f"ID {telegram_id} não encontrado no banco de dados.",
                input_message_content=InputTextMessageContent(
                    message_text=f"Nenhum usuário encontrado com o ID {telegram_id}.",
                    parse_mode="Markdown",
                ),
            )
            await update.inline_query.answer([result], cache_time=0)
    except sqlite3.Error as e:
        logger.error(f"Erro ao consultar o banco de dados: {e}")
        # Mensagem de erro genérica para o usuário
        result = InlineQueryResultArticle(
            id=str(uuid.uuid4()),
            title="Erro no sistema",
            description="Não foi possível completar a operação.",
            input_message_content=InputTextMessageContent(
                message_text="Ocorreu um erro ao processar sua solicitação. Tente novamente mais tarde.",
                parse_mode="Markdown"
            )
        )
        await update.inline_query.answer([result], cache_time=0)
    finally:
        conn.close()
        logger.info("Conexão com o banco de dados encerrada.")

async def button_handler(update: Update, context: CallbackContext):
    """
    Trata os cliques nos botões de confirmação.
    """
    query = update.callback_query
    await query.answer()
    action, telegram_id, credits_change = query.data.split(':')
    telegram_id = int(telegram_id)
    credits_change = int(credits_change)

    if action == "confirm_yes":
        # Adiciona os créditos ao usuário
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        try:
            cursor.execute("UPDATE users SET credits = credits + ? WHERE telegram_id = ?", (credits_change, telegram_id))
            conn.commit()

            cursor.execute("SELECT username, first_name, last_name FROM users WHERE telegram_id = ?", (telegram_id,))
            user_data = cursor.fetchone()
            username, first_name, last_name = user_data
            user_display_name = f"{first_name} {last_name}".strip() or username or f"ID {telegram_id}"

            # Notifica o usuário que adicionou os créditos
            await query.edit_message_text(f"{credits_change} créditos foram adicionados ao ID {telegram_id} ({user_display_name}).")

        except sqlite3.Error as e:
            logger.error(f"Erro ao adicionar créditos: {e}")
            await query.edit_message_text("Erro ao adicionar créditos.")
        finally:
            conn.close()
    elif action == "confirm_remove_yes":
        # Remove os créditos do usuário
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        try:
            cursor.execute("UPDATE users SET credits = credits - ? WHERE telegram_id = ?", (credits_change, telegram_id))
            conn.commit()

            cursor.execute("SELECT username, first_name, last_name FROM users WHERE telegram_id = ?", (telegram_id,))
            user_data = cursor.fetchone()
            username, first_name, last_name = user_data
            user_display_name = f"{first_name} {last_name}".strip() or username or f"ID {telegram_id}"

            # Notifica o usuário que os créditos foram removidos
            await query.edit_message_text(f"{credits_change} créditos foram removidos do ID {telegram_id} ({user_display_name}).")

        except sqlite3.Error as e:
            logger.error(f"Erro ao remover créditos: {e}")
            await query.edit_message_text("Erro ao remover créditos.")
        finally:
            conn.close()
    else:
        # Operação cancelada
        await query.edit_message_text("Operação cancelada.")

async def inline_query_handler(update: Update, context: CallbackContext):
    """
    Lida com pesquisas inline no formato 'id (id do usuário)' ou 'id credits (id do usuário) (quantidade de créditos)',
    exibindo opções para enviar informações no chat.
    """
    query = update.inline_query.query.strip()

    if query.startswith("id credits"):
        await inline_credits_query(update, context)
        return

    if query.startswith("id r credits"):
        await inline_remove_credits_query(update, context)
        return

    # Verifica se a pesquisa começa com 'id' seguido por um número
    if not query.startswith("id ") or not query[3:].isdigit():
        return  # Ignora consultas que não estão no formato correto

    telegram_id = int(query[3:])  # Extrai o ID do usuário

    # Busca informações no banco de dados
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_id,))
        user_data = cursor.fetchone()
    except sqlite3.Error as e:
        logger.error(f"Erro ao buscar usuário: {e}")
        return
    finally:
        conn.close()

    if user_data:
        # Cria a mensagem que será enviada no chat do usuário
        result_message = f"#id {telegram_id}"
        # Resultado da pesquisa inline
        results = [
            InlineQueryResultArticle(
                id=str(uuid.uuid4()),
                title="Encontrei os dados",
                description="Clique aqui",
                input_message_content=InputTextMessageContent(result_message)
            )
        ]
    else:
        # Caso não encontre o usuário
        results = [
            InlineQueryResultArticle(
                id=str(uuid.uuid4()),
                title="Nenhum resultado encontrado",
                description="Nenhum usuário com esse Telegram ID foi encontrado.",
                input_message_content=InputTextMessageContent("Nenhum usuário encontrado.")
            )
        ]

    await update.inline_query.answer(results, cache_time=0)

async def handle_credits_message(update: Update, context: CallbackContext):
    """
    Lida com a mensagem de adicionar créditos enviada no chat.
    """
    message = update.message.text.strip()

    if not message.startswith("#id credits"):
        return  # Ignora mensagens que não seguem o formato esperado

    try:
        _, _, user_id_str, credits_str = message.split()
        telegram_id = int(user_id_str)
        credits_to_add = int(credits_str)
    except ValueError:
        return  # Formato inválido, não processa a mensagem

    # Cria os botões de confirmação
    keyboard = [
        [
            InlineKeyboardButton("Sim", callback_data=f"confirm_yes:{telegram_id}:{credits_to_add}"),
            InlineKeyboardButton("Não", callback_data=f"confirm_no:{telegram_id}:{credits_to_add}")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Pergunta ao usuário se deseja adicionar os créditos
    await update.message.reply_text(
        f"Deseja adicionar {credits_to_add} créditos ao ID {telegram_id}?",
        reply_markup=reply_markup
    )

async def handle_id_message(update: Update, context: CallbackContext):
    """
    Exibe informações detalhadas de um usuário ao receber #id (id do usuário).
    """
    message = update.message.text.strip()

    # Verifica se a mensagem começa com '#id ' seguido por um número
    if not message.startswith("#id ") or not message[4:].isdigit():
        return

    telegram_id = int(message[4:])  # Extrai o ID do usuário

    # Busca informações no banco de dados
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_id,))
        user_data = cursor.fetchone()
    except sqlite3.Error as e:
        logger.error(f"Erro ao buscar usuário: {e}")
        await update.message.reply_text("Erro ao buscar informações.")
        return
    finally:
        conn.close()

    if user_data:
        # Detalhes do usuário
        telegram_id, username, first_name, last_name, start_date, credits, is_blocked = user_data
        user_details = (
            f"🆔 **Telegram ID**: {telegram_id}\n"
            f"👤 **Usuário**: @{username or 'N/A'}\n"
            f"📛 **Nome**: {first_name or 'N/A'} {last_name or ''}\n"
            f"📅 **Data de Início**: {start_date or 'N/A'}\n"
            f"💳 **Créditos**: {credits}\n"
            f"🚫 **Bloqueado**: {'Sim' if is_blocked else 'Não'}"
        )

        # Cria os botões de ação
        keyboard = []

        # Botão de bloqueio ou desbloqueio
        if is_blocked:
            keyboard.append([InlineKeyboardButton("Desbloquear Usuário", callback_data=f"unblock_user:{telegram_id}")])
        else:
            keyboard.append([InlineKeyboardButton("Bloquear Usuário", callback_data=f"block_user:{telegram_id}")])

        # Botão para adicionar créditos
        keyboard.append([
            InlineKeyboardButton("Adicionar Créditos", switch_inline_query_current_chat=f"id credits {telegram_id}"),
            InlineKeyboardButton("Remover Créditos", switch_inline_query_current_chat=f"id r credits {telegram_id}")
        ])

        # Cria a marcação de botões
        reply_markup = InlineKeyboardMarkup(keyboard)

        # Envia a mensagem com os detalhes do usuário e os botões
        msg = await update.message.reply_text(user_details, parse_mode="Markdown", reply_markup=reply_markup)

        async def callback_query_handler(update: Update, context: CallbackContext):
            query = update.callback_query
            callback_data = query.data
            action, telegram_id = callback_data.split(":")
            telegram_id = int(telegram_id)

            # Atualiza o status de bloqueio
            conn = sqlite3.connect(DATABASE_PATH)
            cursor = conn.cursor()
            try:
                if action == "block_user":
                    cursor.execute("UPDATE users SET is_blocked = 1 WHERE telegram_id = ?", (telegram_id,))
                elif action == "unblock_user":
                    cursor.execute("UPDATE users SET is_blocked = 0 WHERE telegram_id = ?", (telegram_id,))
                conn.commit()

                # Busca os dados atualizados do usuário
                cursor.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_id,))
                user_data = cursor.fetchone()
            except sqlite3.Error as e:
                logger.error(f"Erro ao atualizar status do usuário: {e}")
                await query.answer("Erro ao atualizar o status.", show_alert=True)
                return
            finally:
                conn.close()

            if user_data:
                telegram_id, username, first_name, last_name, start_date, credits, is_blocked = user_data
                user_details = (
                    f"🆔 **Telegram ID**: {telegram_id}\n"
                    f"👤 **Usuário**: @{username or 'N/A'}\n"
                    f"📛 **Nome**: {first_name or 'N/A'} {last_name or ''}\n"
                    f"📅 **Data de Início**: {start_date or 'N/A'}\n"
                    f"💳 **Créditos**: {credits}\n"
                    f"🚫 **Bloqueado**: {'Sim' if is_blocked else 'Não'}"
                )

                # Define os botões atualizados
                keyboard = []
                if is_blocked:
                    keyboard.append([InlineKeyboardButton("Desbloquear Usuário", callback_data=f"unblock_user:{telegram_id}")])
                else:
                    keyboard.append([InlineKeyboardButton("Bloquear Usuário", callback_data=f"block_user:{telegram_id}")])

                keyboard.append([
                    InlineKeyboardButton("Adicionar Créditos", switch_inline_query_current_chat=f"id credits {telegram_id}"),
                    InlineKeyboardButton("Remover Créditos", switch_inline_query_current_chat=f"id r credits {telegram_id}")
                ])

                reply_markup = InlineKeyboardMarkup(keyboard)

                # Edita a mensagem original com os dados atualizados
                await msg.edit_text(user_details, parse_mode="Markdown", reply_markup=reply_markup)
                await query.answer("Status atualizado!")
            else:
                await query.answer("Erro ao recuperar os dados do usuário.", show_alert=True)

        # Registra o handler de callback
        application.add_handler(CallbackQueryHandler(callback_query_handler, pattern="^(block_user|unblock_user):"))
    else:
        await update.message.reply_text("Nenhum usuário encontrado com esse Telegram ID.")

async def block_user(update: Update, context: CallbackContext):
    """
    Bloqueia um usuário, impedindo-o de interagir com o bot.
    """
    admin_id = update.effective_user.id
    if admin_id not in ADMIN_IDS:  # Verifique se é um administrador
        await update.message.reply_text("Você não tem permissão para executar este comando.")
        return

    try:
        args = context.args
        telegram_id = int(args[0])

        with sqlite3.connect(DATABASE_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET is_blocked = 1 WHERE telegram_id = ?", (telegram_id,))
            conn.commit()

        await update.message.reply_text(f"Usuário {telegram_id} foi bloqueado com sucesso.")
    except (IndexError, ValueError):
        await update.message.reply_text("Uso: /block_user <telegram_id>")

async def unblock_user(update: Update, context: CallbackContext):
    """
    Desbloqueia um usuário, permitindo interações com o bot.
    """
    admin_id = update.effective_user.id
    if admin_id not in ADMIN_IDS:  # Verifique se é um administrador
        await update.message.reply_text("Você não tem permissão para executar este comando.")
        return

    try:
        args = context.args
        telegram_id = int(args[0])

        with sqlite3.connect(DATABASE_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET is_blocked = 0 WHERE telegram_id = ?", (telegram_id,))
            conn.commit()

        await update.message.reply_text(f"Usuário {telegram_id} foi desbloqueado com sucesso.")
    except (IndexError, ValueError):
        await update.message.reply_text("Uso: /unblock_user <telegram_id>")
# Um dicionário para armazenar os dados temporários do anúncio do usuário
user_ads = {}

async def crate_ad_callback(update: Update, context: CallbackContext):
    query = update.callback_query
    user_id = query.from_user.id
    await query.answer()

    with sqlite3.connect("meubancodedados.db") as conn:
        cursor = conn.cursor()
        
        # Obtém configuração de créditos mínimos
        cursor.execute("SELECT valor FROM config WHERE chave = 'creditos_minimos'")
        creditos_minimos = cursor.fetchone()[0]

        # Verifica usuário no banco de dados
        cursor.execute("SELECT is_blocked, credits FROM users WHERE telegram_id = ?", (user_id,))
        result = cursor.fetchone()

    if result is None:
        await query.message.reply_text("❌ Você não está registrado no sistema. Envie /start para se registrar.")
        return

    is_blocked, credits = result

    if is_blocked == 1:
        await query.message.reply_text("❌ Você está bloqueado e não pode criar anúncios.")
        return

    if credits < creditos_minimos:
        await query.message.reply_text(
            f"Você precisa de pelo menos {creditos_minimos} créditos para criar um anúncio. "
            "Consulte o administrador para obter mais créditos."
        )
        return

    user_ads[user_id] = {"step": 1}

    await query.message.reply_text("Envie a foto ou vídeo que deseja usar no seu anúncio.")

async def handle_media(update: Update, context: CallbackContext):
    """
    Lida com a foto ou vídeo enviado pelo usuário.
    """
    user = update.effective_user
    user_id = user.id

    if user_id not in user_ads or user_ads[user_id]["step"] != 1:
        return  # Ignora mensagens fora do fluxo

    message = update.message

    if message.photo:
        file_id = message.photo[-1].file_id  # Obtém o maior tamanho da foto
        user_ads[user_id]["media"] = ("photo", file_id)
    elif message.video:
        file_id = message.video.file_id
        user_ads[user_id]["media"] = ("video", file_id)
    else:
        await message.reply_text("Por favor, envie uma foto ou vídeo.")
        return

    user_ads[user_id]["step"] = 2

    keyboard = [
        [InlineKeyboardButton("Sim", callback_data="video_call_yes"), InlineKeyboardButton("Não", callback_data="video_call_no")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await message.reply_text(
        "Faz chamada de vídeo?",
        reply_markup=reply_markup
    )

async def handle_video_call_response(update: Update, context: CallbackContext):
    """
    Lida com a resposta sobre chamada de vídeo e avança para a próxima pergunta.
    """
    query = update.callback_query
    user_id = query.from_user.id

    if user_id not in user_ads or user_ads[user_id]["step"] != 2:
        await query.answer()
        return

    await query.answer()

    user_ads[user_id]["video_call"] = query.data == "video_call_yes"
    user_ads[user_id]["step"] = 3

    keyboard = [
        [InlineKeyboardButton("Sim", callback_data="custom_content_yes"), InlineKeyboardButton("Não", callback_data="custom_content_no")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await query.message.reply_text(
        "Faz conteúdos personalizados?",
        reply_markup=reply_markup
    )

async def handle_custom_content_response(update: Update, context: CallbackContext):
    """
    Lida com a resposta sobre conteúdos personalizados e avança para a próxima pergunta.
    """
    query = update.callback_query
    user_id = query.from_user.id

    if user_id not in user_ads or user_ads[user_id]["step"] != 3:
        await query.answer()
        return

    await query.answer()

    user_ads[user_id]["custom_content"] = query.data == "custom_content_yes"
    user_ads[user_id]["step"] = 4

    keyboard = [
        [InlineKeyboardButton("Sim", callback_data="sexting_yes"), InlineKeyboardButton("Não", callback_data="sexting_no")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await query.message.reply_text(
        "Faz sexting?",
        reply_markup=reply_markup
    )

async def handle_sexting_response(update: Update, context: CallbackContext):
    query = update.callback_query
    user_id = query.from_user.id

    if user_id not in user_ads or user_ads[user_id]["step"] != 4:
        await query.answer()
        return

    await query.answer()

    # Obtém as informações do anúncio
    media_type, file_id = user_ads[user_id]["media"]
    does_video_call = user_ads[user_id]["video_call"]
    does_custom_content = user_ads[user_id]["custom_content"]
    does_sexting = query.data == "sexting_yes"

    caption = (
        "🟢 ESTOU DISPONÍVEL AGORA\n\n"
        f"PV liberado para vendas\n➡️ @{query.from_user.username}\n\n"
        f"☎️ Chamadas de vídeo [{'ON✅' if does_video_call else 'OFF❌'}]\n"
        f"🎁 Conteúdos personalizados [{'ON✅' if does_custom_content else 'OFF❌'}]\n"
        f"🥵 Sexting [{'ON✅' if does_sexting else 'OFF❌'}]\n\n"
        f"➡️ @{query.from_user.username}"
    )

    # Salva o anúncio temporariamente no banco de dados
    user_ads[user_id]["caption"] = caption

    # Pergunta o dia para agendamento
    hoje = datetime.now()
    dias_disponiveis = [(hoje + timedelta(days=i)).day for i in range(31)]
    botoes = [
        [InlineKeyboardButton(str(dia), callback_data=f"agendar_dia_{dia}")]
        for dia in dias_disponiveis
    ]
    reply_markup = InlineKeyboardMarkup(botoes)

    await query.message.reply_text(
        "Escolha o dia do mês em que deseja publicar este anúncio:",
        reply_markup=reply_markup,
    )
    user_ads[user_id]["step"] = 5  # Atualiza o passo

async def handle_dia_response(update: Update, context: CallbackContext):
    query = update.callback_query
    user_id = query.from_user.id

    if user_ads[user_id]["step"] != 5:
        await query.answer()
        return

    dia = int(query.data.split("_")[-1])
    user_ads[user_id]["dia"] = dia

    # Pergunta a hora para agendamento
    botoes = [
        [InlineKeyboardButton(f"{hora}:00", callback_data=f"agendar_hora_{hora}")]
        for hora in range(24)
    ]
    reply_markup = InlineKeyboardMarkup(botoes)

    await query.message.reply_text(
        "Escolha a hora em que deseja publicar este anúncio:",
        reply_markup=reply_markup,
    )
    user_ads[user_id]["step"] = 6

async def handle_hora_response(update: Update, context: CallbackContext):
    query = update.callback_query
    user_id = query.from_user.id

    if user_ads[user_id]["step"] != 6:
        await query.answer()
        return

    hora = int(query.data.split("_")[-1])
    user_ads[user_id]["hora"] = hora

    # Pergunta o ano para agendamento, apenas se o mês for dezembro e o dia já passou no mês atual
    hoje = datetime.now()
    mes = hoje.month

    if mes == 12 and user_ads[user_id]["dia"] < hoje.day:
        botoes = [
            [InlineKeyboardButton(str(ano), callback_data=f"agendar_ano_{ano}")]
            for ano in range(hoje.year, hoje.year + 2)
        ]
        reply_markup = InlineKeyboardMarkup(botoes)
        await query.message.reply_text(
            "Escolha o ano em que deseja publicar este anúncio:",
            reply_markup=reply_markup,
        )
        user_ads[user_id]["step"] = 7
    else:
        await agendar_anuncio(update, context)

async def handle_ano_response(update: Update, context: CallbackContext):
    query = update.callback_query
    user_id = query.from_user.id

    if user_ads[user_id]["step"] != 7:
        await query.answer()
        return

    ano = int(query.data.split("_")[-1])
    user_ads[user_id]["ano"] = ano

    await agendar_anuncio(update, context)

async def agendar_anuncio(update: Update, context: CallbackContext):
    query = update.callback_query
    user_id = query.from_user.id
    hoje = datetime.now()

    dia = user_ads[user_id]["dia"]
    hora = user_ads[user_id]["hora"]
    mes = hoje.month
    ano = hoje.year

    # Ajusta para o próximo mês, se necessário
    if dia < hoje.day:
        mes += 1
        if mes > 12:
            mes = 1
            ano += 1

    # Usa o ano fornecido pelo usuário, se disponível
    if "ano" in user_ads[user_id]:
        ano = user_ads[user_id]["ano"]

    # Cria o horário completo
    data_publicacao = datetime(ano, mes, dia, hora, 0)

    # Armazena o agendamento no banco de dados
    caption = user_ads[user_id]["caption"]
    media_type, file_id = user_ads[user_id]["media"]
    with sqlite3.connect("meubancodedados.db") as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO agendamentos (user_id, media_type, file_id, caption, data_publicacao)
            VALUES (?, ?, ?, ?, ?)
            """,
            (user_id, media_type, file_id, caption, data_publicacao),
        )
        conn.commit()

    # Configura a publicação agendada
    scheduler.add_job(
        publicar_anuncio,
        trigger=DateTrigger(run_date=data_publicacao),
        args=[user_id, media_type, file_id, caption],
    )

    await query.message.reply_text(
        f"✅ Seu anúncio foi agendado para {data_publicacao.strftime('%d/%m/%Y %H:%M')}."
    )

    # Limpa os dados temporários
    del user_ads[user_id]

async def publicar_anuncio(user_id, media_type, file_id, caption):
    try:
        if media_type == "photo":
            await context.bot.send_photo(
                chat_id=CHANNEL_ID_1,
                photo=file_id,
                caption=caption,
            )
        elif media_type == "video":
            await context.bot.send_video(
                chat_id=CHANNEL_ID_1,
                video=file_id,
                caption=caption,
            )
    except Exception as e:
        logger.error(f"Erro ao publicar anúncio agendado para {user_id}: {e}")

def atualizar_creditos(telegram_id, valor):
    """Atualiza os créditos do usuário no banco."""
    try:
        connection = sqlite3.connect('meubancodedados.db')
        cursor = connection.cursor()

        # Verificar se o usuário já está registrado
        cursor.execute("SELECT credits FROM users WHERE telegram_id = ?", (telegram_id,))
        result = cursor.fetchone()

        # Converter valor em créditos
        novos_creditos = valor * 100

        if result:
            # Atualizar créditos existentes
            creditos_atualizados = result[0] + novos_creditos
            cursor.execute("UPDATE users SET credits = ? WHERE telegram_id = ?", (creditos_atualizados, telegram_id))
        else:
            # Inserir novo usuário com créditos
            cursor.execute(
                "INSERT INTO users (telegram_id, credits) VALUES (?, ?)",
                (telegram_id, novos_creditos)
            )

        connection.commit()
        logger.info(f"Créditos atualizados: Telegram ID: {telegram_id}, Créditos: {novos_creditos}")
    except Exception as e:
        logger.error(f"Erro ao atualizar créditos no banco: {str(e)}")
    finally:
        connection.close()


# Função para gerar QR Code PIX usando a SDK do Mercado Pago
async def gerar_qrcode_pix(valor, description):
    try:
        payment_data = {
            "transaction_amount": valor,
            "description": description,
            "payment_method_id": "pix",
            "payer": {
                "email": "payer@example.com",
                "first_name": "Test",
                "last_name": "User",
                "identification": {
                    "type": "CPF",
                    "number": "19119119100"
                },
                "address": {
                    "zip_code": "06233-200",
                    "street_name": "Av. das Nações Unidas",
                    "street_number": "3003",
                    "neighborhood": "Bonfim",
                    "city": "Osasco",
                    "federal_unit": "SP"
                }
            }
        }

        payment_response = sdk.payment().create(payment_data)
        payment = payment_response["response"]

        qr_code_base64 = payment["point_of_interaction"]["transaction_data"]["qr_code_base64"]
        qr_code_text = payment["point_of_interaction"]["transaction_data"]["qr_code"]
        payment_id = payment["id"]

        qr_code_image = base64.b64decode(qr_code_base64)
        qr_code_image = BytesIO(qr_code_image)

        return qr_code_image, qr_code_text, payment_id
    except Exception as e:
        logger.error(f"Erro ao gerar QR Code PIX: {str(e)}")
        return None, None, None
      
# Função para checar status de pagamento com logs detalhados
def checar_status_pagamento(payment_id):
    try:
        logger.info(f"Verificando status do pagamento para ID: {payment_id}")
        payment_response = sdk.payment().get(payment_id)

        if payment_response.get("status") == 200:
            payment_info = payment_response.get("response", {})
            status = payment_info.get('status')
            logger.info(f"Status do pagamento (ID {payment_id}): {status}")
            return status
        else:
            logger.error(f"Erro ao verificar status do pagamento. Resposta: {payment_response.get('response')}")
            return None
    except Exception as e:
        logger.error(f"Erro ao tentar verificar o pagamento (ID {payment_id}): {str(e)}")
        return None
      

async def selecionar_plano(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    chat_id = query.message.chat_id
    data = query.data

    if data.startswith("contribuir:"):
        plano_id = int(data.split(":")[1])

        with sqlite3.connect("meubancodedados.db") as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT valor, creditos FROM planos_contribuicao WHERE id = ?", (plano_id,))
            plano = cursor.fetchone()

        if not plano:
            await query.answer("Plano não encontrado.")
            return

        valor, creditos = plano
        description = f"Contribuição no valor de R$ {valor}"
        qr_code_image, qr_code_text, payment_id = await gerar_qrcode_pix(valor, description)

        if qr_code_image:
            # Armazenar informações do pagamento no dicionário global
            pagamentos_em_progresso[payment_id] = {"chat_id": chat_id, "valor": valor, "creditos": creditos}

            expiracao = datetime.now() + timedelta(minutes=20)
            data_expiracao = expiracao.strftime("%d/%m/%Y às %H:%M:%S")

            legenda = (
                f"💰 *ADICIONAR SALDO COM PIX AUTOMÁTICO* 💠\n\n"
                f"⏰| *Expira em*: {data_expiracao}\n"
                f"💸| *Valor*: R$ {valor}\n"
                f"🆔| *ID da compra*: {payment_id}\n\n"
                f"💠 Créditos adicionados: {creditos}\n\n"
                f"📃 Este é o código \"copia e cola\" válido para 1 pagamento!\n\n"
                f"💠 *PIX COPIA E COLA* 👇\n\n"
                f"{qr_code_text}\n\n"
                f"💡 *DICA*: Clique no código acima para copiá-lo."
            )

            keyboard = [
                [InlineKeyboardButton("❌ Cancelar Pagamento", callback_data=f"cancelar_pagamento:{payment_id}")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)

            await context.bot.send_photo(
                chat_id=chat_id,
                photo=qr_code_image,
                caption=legenda,
                parse_mode="Markdown",
                reply_markup=reply_markup
            )

            asyncio.create_task(verificar_pagamento(chat_id, payment_id, context))
            asyncio.create_task(expirar_qr_code(chat_id, payment_id, context, expiracao))
        else:
            await query.edit_message_text(text="Houve um problema ao gerar o QR Code PIX. Tente novamente mais tarde.")


# Função para gerenciar a expiração do QR Code
async def expirar_qr_code(chat_id: int, payment_id: str, context: CallbackContext, expiracao: datetime) -> None:
    # Aguarda o tempo restante até a expiração
    tempo_restante = (expiracao - datetime.now()).total_seconds()
    if tempo_restante > 0:
        await asyncio.sleep(tempo_restante)
    
    # Verifica se o pagamento ainda não foi processado
    if not await verificar_pagamento_concluido(payment_id):  # Suponha que esta função verifica o status
        # Notifica o usuário que o QR Code expirou
        await context.bot.send_message(
            chat_id=chat_id,
            text=(
                "⚠️ *QR Code expirado!*\n\n"
                "O código PIX gerado expirou após 20 minutos e não pode mais ser usado.\n"
                "Se ainda deseja adicionar saldo, por favor gere um novo código usando o comando /pix."
            ),
            parse_mode="Markdown"
        )

async def verificar_pagamento(chat_id: int, payment_id: str, context: CallbackContext) -> None:
    logger.info(f"Iniciando verificação de pagamento para ID {payment_id}...")
    start_time = datetime.now()
    timeout = timedelta(minutes=20)
    status = None

    while (datetime.now() - start_time) < timeout:
        async with pagamentos_cancelados_lock:
            if payment_id in pagamentos_cancelados:
                logger.info(f"Verificação interrompida: pagamento {payment_id} foi cancelado.")
                await context.bot.send_message(
                    chat_id,
                    "⚠️ A verificação foi cancelada. O pagamento não será processado."
                )
                return

        logger.info(f"Verificando status do pagamento para ID {payment_id}...")
        status = checar_status_pagamento(payment_id)

        if status == 'approved':
            logger.info(f"Pagamento aprovado para ID {payment_id}.")

            # Recuperar informações do plano
            pagamento_info = pagamentos_em_progresso.pop(payment_id, None)
            if pagamento_info:
                creditos = pagamento_info["creditos"]
                valor = pagamento_info["valor"]

                # Atualizar créditos do usuário
                atualizar_creditos(chat_id, creditos)

                await context.bot.send_message(
                    chat_id,
                    f"✅ Obrigado! Seu pagamento de R$ {valor} foi aprovado. Você recebeu {creditos} créditos."
                )
            else:
                logger.error(f"Informações do pagamento {payment_id} não encontradas.")

            return

        await asyncio.sleep(10)

    logger.warning(f"Pagamento não aprovado dentro do tempo limite para ID {payment_id}. Status final: {status}")
    await context.bot.send_message(chat_id, "⚠️ Seu pagamento não foi aprovado dentro do tempo limite. Tente novamente mais tarde.")

def obter_valor_pagamento(payment_id):
    """Obtém o valor do pagamento com base no ID."""
    try:
        payment_response = sdk.payment().get(payment_id)
        if payment_response.get("status") == 200:
            payment_info = payment_response.get("response", {})
            valor = payment_info.get("transaction_amount")
            return valor
        else:
            logger.error(f"Erro ao obter valor do pagamento. Resposta: {payment_response.get('response')}")
            return 0
    except Exception as e:
        logger.error(f"Erro ao tentar obter o valor do pagamento (ID {payment_id}): {str(e)}")
        return 0

async def cancelar_pagamento(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    await query.answer()

    # Extrair o payment_id do callback_data
    callback_data = query.data
    payment_id = callback_data.split(":")[1]

    # Adicionar o payment_id à lista de cancelados (com Lock)
    async with pagamentos_cancelados_lock:
        pagamentos_cancelados.add(payment_id)
    logger.info(f"Pagamento {payment_id} foi cancelado pelo usuário.")

    # Exclui a mensagem original (se possível)
    if query.message:
        await query.message.delete()

    # Envia nova mensagem informando o cancelamento
    await context.bot.send_message(
        chat_id=query.from_user.id,
        text="⚠️ O pagamento foi cancelado. Se desejar, gere um novo QR Code com o comando /pix."
    )


async def verificar_creditos(update: Update, context: CallbackContext) -> None:
    telegram_id = update.message.chat_id
    try:
        connection = sqlite3.connect('meubancodedados.db')
        cursor = connection.cursor()
        cursor.execute("SELECT credits FROM users WHERE telegram_id = ?", (telegram_id,))
        result = cursor.fetchone()

        if result:
            await update.message.reply_text(f"Você tem {result[0]} créditos disponíveis.")
        else:
            await update.message.reply_text("Você ainda não tem créditos disponíveis.")
    except Exception as e:
        logger.error(f"Erro ao verificar créditos: {str(e)}")
        await update.message.reply_text("Houve um erro ao verificar seus créditos. Tente novamente mais tarde.")
    finally:
        connection.close()


# Função para enviar uma mensagem ao usuário no Telegram
def enviar_mensagem_telegram(chat_id, mensagem):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    data = {"chat_id": chat_id, "text": mensagem}
    response = requests.post(url, data=data)
    
    if response.status_code != 200:
        print(f"Erro ao enviar mensagem ao Telegram: {response.text}")

if __name__ == '__main__':
    create_tables()
    application = Application.builder().token(TOKEN).build()

    # Inicializa o agendador
    def start_scheduler():
        scheduler.start()

    # Inicializa a thread para rodar o Flask
    thread_flask = threading.Thread(target=run_flask)
    thread_flask.start()

    # Adicionar handlers ao aplicativo
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(crate_ad_callback, pattern="crate_ad"))
    application.add_handler(MessageHandler(filters.Regex(r"^#id \d+$"), handle_id_message))
    application.add_handler(InlineQueryHandler(inline_query_handler))
    application.add_handler(InlineQueryHandler(inline_credits_query))
    application.add_handler(CallbackQueryHandler(button_handler, pattern=r'^confirm_'))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_credits_message))
    application.add_handler(MessageHandler(filters.PHOTO | filters.VIDEO, handle_media))
    application.add_handler(CallbackQueryHandler(handle_video_call_response, pattern="video_call_yes|video_call_no"))
    application.add_handler(CallbackQueryHandler(handle_custom_content_response, pattern="custom_content_yes|custom_content_no"))
    application.add_handler(CallbackQueryHandler(handle_sexting_response, pattern="sexting_yes|sexting_no"))
    application.add_handler(CommandHandler("creditos", verificar_creditos))
    application.add_handler(CallbackQueryHandler(cancelar_pagamento, pattern=r"^cancelar_pagamento:"))
    application.add_handler(CallbackQueryHandler(contribuir, pattern=r'^contribuir$'))
    application.add_handler(CallbackQueryHandler(selecionar_plano, pattern=r'^contribuir:\d+$'))

    # Adicionar handlers para seleção de dia, hora e ano
    application.add_handler(CallbackQueryHandler(handle_dia_response, pattern=r"^agendar_dia_\d+$"))
    application.add_handler(CallbackQueryHandler(handle_hora_response, pattern=r"^agendar_hora_\d+$"))
    application.add_handler(CallbackQueryHandler(handle_ano_response, pattern=r"^agendar_ano_\d+$"))

    # Inicializar o bot
    print("Iniciando o bot...")
    application.run_polling()
    print("Bot iniciado.")